function [vdRowBounds, vdColBounds, vdSliceBounds] = GetMaskBoundsFromBitLabelMap_uint16(m3ui16BitLabelMap, dBitPosition)

[vdRowBounds, vdColBounds, vdSliceBounds] = GetMaskBoundsFromBitLabelMap(m3ui16BitLabelMap, dBitPosition);

end

