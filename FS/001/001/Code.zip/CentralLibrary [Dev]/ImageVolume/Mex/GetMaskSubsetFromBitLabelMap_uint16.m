function m3bMask = GetMaskSubsetFromBitLabelMap_uint16(m3ui16BitLabelMap, dBitPosition, vdRowBounds, vdColBounds, vdSliceBounds)

m3bMask = GetMaskSubsetFromBitLabelMap(m3ui16BitLabelMap, dBitPosition, vdRowBounds, vdColBounds, vdSliceBounds);

end

