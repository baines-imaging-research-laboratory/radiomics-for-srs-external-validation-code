function m3bMask = GetMaskSubsetFromBitLabelMap_uint64(m3ui64BitLabelMap, dBitPosition, vdRowBounds, vdColBounds, vdSliceBounds)

m3bMask = GetMaskSubsetFromBitLabelMap(m3ui64BitLabelMap, dBitPosition, vdRowBounds, vdColBounds, vdSliceBounds);

end

