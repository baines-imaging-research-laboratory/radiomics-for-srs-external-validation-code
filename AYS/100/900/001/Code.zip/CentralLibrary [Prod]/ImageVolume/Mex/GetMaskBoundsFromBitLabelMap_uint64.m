function [vdRowBounds, vdColBounds, vdSliceBounds] = GetMaskBoundsFromBitLabelMap_uint64(m3ui64BitLabelMap, dBitPosition)

[vdRowBounds, vdColBounds, vdSliceBounds] = GetMaskBoundsFromBitLabelMap(m3ui64BitLabelMap, dBitPosition);

end

