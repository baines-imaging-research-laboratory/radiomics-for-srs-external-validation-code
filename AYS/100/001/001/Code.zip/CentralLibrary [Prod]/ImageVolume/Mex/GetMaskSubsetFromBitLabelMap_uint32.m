function m3bMask = GetMaskSubsetFromBitLabelMap_uint32(m3ui32BitLabelMap, dBitPosition, vdRowBounds, vdColBounds, vdSliceBounds)

m3bMask = GetMaskSubsetFromBitLabelMap(m3ui32BitLabelMap, dBitPosition, vdRowBounds, vdColBounds, vdSliceBounds);

end

