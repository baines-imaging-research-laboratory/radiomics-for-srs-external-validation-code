function [vdRowBounds, vdColBounds, vdSliceBounds] = GetMaskBoundsFromBitLabelMap_uint8(m3ui8BitLabelMap, dBitPosition)

[vdRowBounds, vdColBounds, vdSliceBounds] = GetMaskBoundsFromBitLabelMap(m3ui8BitLabelMap, dBitPosition);

end

