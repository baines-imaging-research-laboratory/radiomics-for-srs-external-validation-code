classdef StudyConstants
    %StudyConstants
    
    properties (Constant)
        sAnonymizationStudyTag = "BRAIN METS SRS SRT"
        dPatientStudyIdNumDigits = 4
    end
end

