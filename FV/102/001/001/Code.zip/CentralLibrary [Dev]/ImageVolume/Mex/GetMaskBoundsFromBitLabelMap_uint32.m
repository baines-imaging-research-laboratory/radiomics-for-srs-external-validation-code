function [vdRowBounds, vdColBounds, vdSliceBounds] = GetMaskBoundsFromBitLabelMap_uint32(m3ui32BitLabelMap, dBitPosition)

[vdRowBounds, vdColBounds, vdSliceBounds] = GetMaskBoundsFromBitLabelMap(m3ui32BitLabelMap, dBitPosition);

end

