function m3bMask = GetMaskSubsetFromBitLabelMap_uint8(m3ui8BitLabelMap, dBitPosition, vdRowBounds, vdColBounds, vdSliceBounds)

m3bMask = GetMaskSubsetFromBitLabelMap(m3ui8BitLabelMap, dBitPosition, vdRowBounds, vdColBounds, vdSliceBounds);

end

