# ComBat harmonization in R

- neuroCombat: R package (software package)
- neuroCombatData: R package (data package)