Version 1.0.1
    - Bugfix when features have constant values for a given scanner/batch group.